<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="donation.css">
  <title>Donation</title>
  <style>
    body {
      background-color: #B8BCA9;
    }
  </style>
</head>
<body>
  <h3 align="center" style="color:black;margin-top: 2%;">Please give the following details for the donation process</h3>
  <div class="container">
    <div class="form">
      <form id="form" action="<?php echo $_SERVER["PHP_SELF"]?>" method="post">
        <div class="text-1">
            <div>
                <label for="fname">First name:</label>
                <input type="text" id="fname" name="fname">
                <div class="error"></div>
                <br>
            </div>
            <div>
                <label for="lname">Last name:</label>
                <input type="text" id="lname" name="lname">
                <div class="error"></div>
                <br>
            </div>
            <div>
                <label for="ContactNo">Contact Number:</label>
                <input type="text" id="ContactNo" name="ContactNo" placeholder="Please give the same as the one you give in the hospital">
                <div class="error"></div>
                <br>
            </div>
        </div>
        <input type="button" value="Submit" onclick="errorMessage()">            
      </form>
    </div>
  </div>
  <script src="finance.js"></script>
</body>
</html>

<?php
    $servername = "localhost";
    $username = "root"; 
    $dbpassword = ""; 
    $dbname = "icms";


if($_SERVER["REQUEST_METHOD"] == "POST"){

    $conn = mysqli_connect($servername,$username,$dbpassword,$dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
	
    $fname = mysqli_real_escape_string($conn, $_POST["fname"]);
    $lname = mysqli_real_escape_string($conn, $_POST["lname"]);
    $Contactno = mysqli_real_escape_string($conn, $_POST["ContactNo"]);
    $solve="SELECT * FROM hospital WHERE Contactno = '$Contactno' ";
    $sql = "INSERT INTO acceptor (fname, lname, ContactNo) VALUES ('$fname', '$lname', '$Contactno')";
    $sqlquery="SELECT * FROM hospital WHERE fname = '$fname' AND lname = '$lname' AND Contactno = '$Contactno' ";
    $query = "SELECT * FROM donation";
    $solution=mysqli_query($conn,$sqlquery);
    $result = mysqli_query($conn, $query);
    $solsolve = mysqli_query($conn, $query);
    if($solsolve>0){
        header("Location:pass.html");
    }
    if (mysqli_query($conn,$sql) === TRUE) {
        if (mysqli_num_rows($solution)>0) {
            if (mysqli_num_rows($result)>0) {
                header("Location: newpage.php");
            }
            else {
                header("Location:failed.html");
            }
        }
        else{
                header("Location:failed1.html");
            }
    }
     else {
        header("Location:failed2.html");
    }
    

    mysqli_close($conn);

}

?>