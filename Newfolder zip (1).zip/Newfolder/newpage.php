<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donator Details</title>
  <style>
    body {
      background-color: #B8BCA9;
      font-family: Arial, sans-serif;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      background-color: #FFFFFF;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      margin-top: 50px;
    }
    h3 {
      text-align: center;
      color: #333333;
    }
    .details {
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h3>The details of the donators are as follows:</h3>
    <div class="details">
      <?php
      $servername = "localhost";
      $username = "root";
      $dbpassword = "";
      $dbname = "icms";

      // Create connection
      $conn = mysqli_connect($servername, $username, $dbpassword, $dbname);

      // Check connection
      if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
      }

      // SQL query
      $sql = "SELECT * FROM donation";
      $result = mysqli_query($conn, $sql);

      if (!$result) {
          echo "Error: " . mysqli_error($conn);
      } else {
          // Display data
          while ($row = mysqli_fetch_assoc($result)) {
              echo "First Name: " . $row['fname'] . "<br>";
              echo "Last Name: " . $row['lname'] . "<br>";
              echo "Contact No: " . $row['ContactNo'] . "<br>";
              echo "Alternate Contact No: " . $row['Alternatecontactno'] . "<br>";
              echo "Email: " . $row['email'] . "<br>";
              echo "<hr>";
          }

          // Free result set
          mysqli_free_result($result);
      }

      // Close connection
      mysqli_close($conn);
      ?>
    </div>
  </div>
</body>
</html>
