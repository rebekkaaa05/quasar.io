<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="donation.css">
  <title>Donation</title>
  <style>
    body {
      background-color: #B8BCA9;
    }
  </style>
</head>
<body>
  <h3 align="center" style="color:black;margin-top: 2%;">Please give the following details for the donation process</h3>
  <div class="container">
    <div class="form">
      <form id="form" action="<?php echo $_SERVER["PHP_SELF"]?>" method="post">
        <div class="text-1">
            <div>
                <label for="fname">First name:</label>
                <input type="text" id="fname" name="fname">
                <div class="error"></div>
                <br>
            </div>
            <div>
                <label for="lname">Last name:</label>
                <input type="text" id="lname" name="lname">
                <div class="error"></div>
                <br>
            </div>
            <div>
                <label for="ContactNo">Contact Number:</label>
                <input type="text" id="ContactNo" name="ContactNo">
                <div class="error"></div>
                <br>
            </div>
            <div>
                <label for="Alternativecontactno">Alternative Contact Number:</label>
                <input type="text" id="Alternativecontactno" name="Alternativecontactno">
                <div class="error"></div>
                <br>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email">
                <div class="error"></div>
                <br>
            </div>
        </div>
        <input type="button" value="Submit" onclick="errorMessage()">            
      </form>
    </div>
  </div>
  
  <script src="donation.js"></script>
</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$dbpassword = "";
$dbname = "icms";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = mysqli_connect($servername, $username, $dbpassword, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve form data
    $fname = mysqli_real_escape_string($conn, $_POST["fname"]);
    $lname = mysqli_real_escape_string($conn, $_POST["lname"]);
    $ContactNo = mysqli_real_escape_string($conn, $_POST["ContactNo"]);
    $Alternatecontactno = mysqli_real_escape_string($conn, $_POST["Alternativecontactno"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);

    // Insert into database
    $sql = "INSERT INTO donation (fname, lname, ContactNo, Alternatecontactno, email) VALUES ('$fname', '$lname', '$ContactNo', '$Alternatecontactno', '$email')";

    // Debugging: Output the SQL query
    echo "SQL Query: " . $sql . "<br>";

    if (mysqli_query($conn, $sql)) {
        mysqli_close($conn);
        header("Location: finalpage.html");
    } else {
      header("Location:donation.php");
    }

    mysqli_close($conn);
}
?>
