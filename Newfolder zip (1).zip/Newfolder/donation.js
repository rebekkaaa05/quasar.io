let id = (id) => document.getElementById(id);
let classes = (classes) => document.getElementsByClassName(classes);


let fname = id("fname"),
  lname = id("lname"),
  email = id("email"),
  ContactNo = id("ContactNo"),
  Alternativecontactno = id("Alternativecontactno"),
  errorMsg = classes("error"),
  form = document.querySelector("form");

function errorMessage() {
  let l0 = 1, l1 = 1, l2 = 1, l3 = 1, l4 = 1;

  if (fname.value.trim() === "") {
    errorMsg[0].innerHTML = "First name cannot be blank";
    l0 = 0;
  } else {
    errorMsg[0].innerHTML = "";
  }

  if (lname.value.trim() === "") {
    errorMsg[1].innerHTML = "Last name cannot be blank";
    l2 = 0;
  } else {
    errorMsg[1].innerHTML = "";
  }

  if (ContactNo.value.trim() === "") {
    errorMsg[2].innerHTML = "Contact Number cannot be blank";
    l3 = 0;
  } else {
    errorMsg[2].innerHTML = "";
  }

  if (Alternativecontactno.value.trim() === "") {
    errorMsg[3].innerHTML = "Alternative Contact Number cannot be blank";
    l4 = 0;
  } else {
    errorMsg[3].innerHTML = "";
  }

  if (email.value.trim() === "") {
    errorMsg[4].innerHTML = "Email cannot be blank";
    l1 = 0;
  } else {
    errorMsg[4].innerHTML = "";
  }

  if (l0 == 1 && l1 == 1 && l2 == 1 && l3 == 1 && l4 == 1) {
    form.submit(); 
  }
}

