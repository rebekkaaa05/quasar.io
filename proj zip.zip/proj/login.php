<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <title>ICMS first page</title>
</head>
<body>
    <style>
        body {
  background-image: url('image.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
}
    </style>
    <div class="container">
        <div class="content">
            <div class="logo">
                <img src="logo.svg" height="100" width="140">
            </div>
        </div>
        <form id="form" action="<?php echo $_SERVER["PHP_SELF"]?>" method="post">
            <div class="social">
                <div class="title">Get Started</div>
                <div class="question">
                    Already have an account?? <br>
                    <a style="color:#f2796e"; href="signin.php">Sign in</a>
                    
                </div>
    <!--           <div class="btn">
                    <div class="btn-1">
                        <img src="https://img.icons8.com/?size=30&id=17949&format=png&color=000000"/>
                        Sign Up
                        
                    </div>
                    <div class="btn-2">
                        <img src="https://img.icons8.com/?size=30&id=118466&format=png&color=ffffff"/>
                        Sign Up
                    </div>
                </div>-->
                <div class="or">Or</div>
            </div>
            <!-- /**
            * !USER NAME INPUT HERE
            **/ -->
            <div>
                <label for="Username">Username</label>
                <i class="fa-solid fa-user"></i>
                <input type="text" id="Username" placeholder="Username" name="Username">
                <i class="fa-solid fa-circle-exclamation failure-icon"></i>
                <i class="fa-solid fa-check success-icon"></i>
                <div class="error"></div>
            </div>
            <!-- /**
            * !EMAIL INPUT HERE
            **/ -->
            <div>
                <label for="Email">Email</label>
                <i class="fa-regular fa-envelope"></i>
                <input type="Email" id="Email" placeholder="abc@gmail.com" name="Email">
                <i class="fa-solid fa-circle-exclamation failure-icon"></i>
                <i class="fa-solid fa-check success-icon"></i>
                <div class="error"></div>
            </div>
            <!-- /**
            * !PASSWORD INPUT HERE
            **/ -->
            <div>
                <label for="Password">Password</label>
                <i class="fa-solid fa-lock"></i>
                <input type="Password" id="Password" placeholder="Password here" name="UserPassword">
                <i class="fa-solid fa-circle-exclamation failure-icon"></i>
                <i class="fa-solid fa-check success-icon"></i>
                <div class="error"></div>
            </div>

            <input type="button" value="submit" onclick="errorMessage()">
        </form>
        <div class="text">
            <h1 style="color:aliceblue;font-family:'Times New Roman', Times, serif;font-size: 60px;" >ICMS</h1>
            <hr>
            <h3 style="color:aliceblue;font-family:'Times New Roman', Times, serif;font-size: 10px;" text-align="right">Where your health is taken care of</h3>
        </div>
    </div>
</body>
<script src="login.js">
</script>
</html>


<?php
    $servername = "localhost";
    $username = "root"; 
    $dbpassword = ""; 
    $dbname = "icms";


if($_SERVER["REQUEST_METHOD"] == "POST"){

    $conn = mysqli_connect($servername,$username,$dbpassword,$dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
	
	$user = $_POST["Username"];
	$email = $_POST["Email"];
	$password = $_POST["UserPassword"];

    $query = "SELECT * FROM firstpage WHERE Email='$email'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 1) {
        // Login successful
        header("Location: newpage.html");
    }
	$sql = "INSERT INTO firstpage (Username,Email,Password) VALUES ('$user', '$email','$password')";

    
    if (mysqli_query($conn,$sql) === TRUE) {
        echo '<script>openHome()</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    mysqli_close($conn);

}

?>