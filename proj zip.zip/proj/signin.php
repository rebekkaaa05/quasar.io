<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sign.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <title>Sign in</title>
</head>
<body>
    <style>
        body {
  background-image: url('secondpg.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
}
</style>
    <div class="container">
        <div class="content">
            <div class="logo">
                <img src="logo.svg" height="100" width="140">
            </div>
        </div>
        <form id="form" action="<?php echo $_SERVER["PHP_SELF"]?>" method="post">
    <!-- Username -->
    <div>
        <label for="Username">Username</label>
        <input type="text" id="Username" name="Username" placeholder="Username">
        <div class="error"></div>
    </div>
    <!-- Email -->
    <div>
        <label for="Email">Email</label>
        <input type="email" id="Email" name="Email" placeholder="abc@gmail.com">
        <div class="error"></div>
    </div>
    <!-- Password -->
    <div>
        <label for="Password">Password</label>
        <input type="password" id="Password" name="Password" placeholder="Password here">
        <div class="error"></div>
    </div>
    <div class="forgotpassword" align="Right">
        <a href="resetpassword.php">Forgot password?</a>
    </div>
    <input type="submit" value="Submit" id="submit" onclick="errorMessage()">
</form>
        <div class="text">
            <h1 style="color:aliceblue;font-family:'Times New Roman', Times, serif;font-size: 60px;" >ICMS</h1>
            <hr>
        </div>
    </div>
</body>
<script src="signin.js"></script>
</html>

<?php
$servername = "localhost";
$username = "root";
$dbpassword = "";
$dbname = "icms";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = mysqli_connect($servername, $username, $dbpassword, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $user = $_POST["Username"];
    $email = $_POST["Email"];
    $password = $_POST["Password"];

    // Prevent SQL injection (recommended to use prepared statements instead)
    $user = mysqli_real_escape_string($conn, $user);
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    $query = "SELECT * FROM firstpage WHERE Username='$user' AND Email='$email' AND Password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // Login successful
        header("Location: main1.html");
    }
     else {
        if($user=="" or $email=="" or $password==""){
            header("Location:signin.php");
        }
        else {
        header("Location: failure.html");
        }
    }

    mysqli_close($conn);
}
?>
