<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forgotpassword.css">
    <title>Reset Password</title>
</head>
<body>
<style>
    body {
        background-color:#D3A381;
    }
</style>
<div class="container">
    <form id="form" action="<?php echo $_SERVER["PHP_SELF"]?>" method="POST">
        <div>
        <label for="Email">Email</label>
            <input type="email" id="Email" placeholder="abc@gmail.com" name="Email">
            <div class="error"></div>
            <label for="NewPassword">New Password</label>
            <input type="password" id="NewPassword" placeholder="New Password" name="NewPassword" required>
            <div class="error"></div>
        </div>
        <input type="submit" value="Submit" onclick="errorMessage()">
    </form>
</div>
</body>
<script src="resetpassword.js"></script>
</html>

<?php
$servername = "localhost";
$username = "root"; 
$dbpassword = ""; 
$dbname = "icms";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = mysqli_connect($servername, $username, $dbpassword, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $NewPassword = $_POST["NewPassword"];
    $email = $_POST["Email"];
    $NewPassword = mysqli_real_escape_string($conn, $NewPassword);
    $email = mysqli_real_escape_string($conn, $email);
    

    $query = "UPDATE firstpage SET Password='$NewPassword' WHERE Email = '$email'";

    if (mysqli_query($conn, $query)) {
        header("Location: main1.html");
        exit(); 
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

