let id = (id) => document.getElementById(id);
let classes = (classes) => document.getElementsByClassName(classes); 
let username = id("Username"),
  email = id("Email"),
  password = id("Password");
  errorMsg=classes("error");
  form = document.getElementById("form");

  function errorMessage() {

    if (document.getElementById("Email").value.trim()==="") 
    {
         errorMsg[0].innerHTML="Email cannot be blank";
         l0=0;
    } 
    else {
        errorMsg[0].innerHTML=" ";
        l0=1;
    }
    if (document.getElementById("NewPassword").value.trim()==="") 
    {
        errorMsg[1].innerHTML="Password cannot be blank";
        l1=0;
    }
    else {
        errorMsg[1].innerHTML=" ";
        l1=1;
    }
    if (l0==1 && l1==1){
        form.submit();   // FORM SUBMITTED TO PHP FILE AFTER CHECKING THE USERNAME,EMAIL,PASSWORD ENTERED ARE CORERCT
    }
}
